#include <stdio.h>
int a, b, soma;
int main(){
	printf("================================");
	printf("\nDigite o primeiro numero: ");
	scanf("%i", &a);
	fflsuh(stdin);
	printf("\nDigite o segundo numero: ");
	scanf("%i", &b);
	fflsuh(stdin);
	soma= a+b;
	printf("================================");
	printf("\nA soma de %d = %d\n", a,b,soma);
	printf("================================");
}